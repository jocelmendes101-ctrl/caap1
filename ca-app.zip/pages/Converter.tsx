
import React, { useState } from 'react';
import { ArrowRightLeft } from 'lucide-react';

const Converter: React.FC = () => {
  const [val, setVal] = useState<string>('1');
  const rates: Record<string, number> = {
    'USD-EUR': 0.92,
    'USD-BRL': 4.95,
    'USD-AOA': 830,
    'USD-CVE': 102.30,
    'EUR-USD': 1.09,
    'EUR-BRL': 5.38,
    'EUR-AOA': 902,
    'EUR-CVE': 110.26,
    'BRL-USD': 0.20,
    'BRL-EUR': 0.18,
    'BRL-AOA': 167,
    'BRL-CVE': 20.66,
    'AOA-USD': 0.0012,
    'AOA-EUR': 0.0011,
    'AOA-BRL': 0.0060,
    'AOA-CVE': 0.12,
    'CVE-USD': 0.0098,
    'CVE-EUR': 0.0090,
    'CVE-BRL': 0.048,
    'CVE-AOA': 8.11
  };

  const [from, setFrom] = useState('USD');
  const [to, setTo] = useState('CVE');

  const result = parseFloat(val) * (from === to ? 1 : (rates[`${from}-${to}`] || 1));

  return (
    <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 max-w-md mx-auto">
      <h1 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
        <ArrowRightLeft className="text-blue-600" /> Conversor de Moeda
      </h1>
      
      <div className="space-y-4">
        <input type="number" value={val} onChange={e => setVal(e.target.value)} className="w-full text-3xl font-bold text-center bg-slate-50 p-4 rounded-2xl border-none outline-none text-blue-600 focus:ring-2 focus:ring-blue-100 transition-all" />
        
        <div className="grid grid-cols-2 gap-4">
          <select value={from} onChange={e => setFrom(e.target.value)} className="bg-slate-100 p-3 rounded-xl font-bold text-slate-900 outline-none">
            <option value="USD">USD ($)</option>
            <option value="EUR">EUR (€)</option>
            <option value="BRL">BRL (R$)</option>
            <option value="AOA">AOA (Kz)</option>
            <option value="CVE">CVE ($00)</option>
          </select>
          <select value={to} onChange={e => setTo(e.target.value)} className="bg-slate-100 p-3 rounded-xl font-bold text-slate-900 outline-none">
            <option value="CVE">CVE ($00)</option>
            <option value="EUR">EUR (€)</option>
            <option value="USD">USD ($)</option>
            <option value="BRL">BRL (R$)</option>
            <option value="AOA">AOA (Kz)</option>
          </select>
        </div>

        <div className="p-6 bg-slate-900 text-white rounded-2xl text-center">
          <p className="text-slate-400 text-xs font-bold uppercase mb-1">Resultado Estimado</p>
          <p className="text-4xl font-black">{result.toFixed(2)} {to}</p>
          <p className="text-[10px] text-slate-500 mt-4 italic">Câmbio médio comercial (taxas locais base)</p>
        </div>
      </div>
    </div>
  );
};

export default Converter;
