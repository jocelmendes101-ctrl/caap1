
import React, { useState } from 'react';

const Investment: React.FC = () => {
  const [initial, setInitial] = useState<string>('');
  const [monthly, setMonthly] = useState<string>('');
  const [rate, setRate] = useState<string>('');
  const [years, setYears] = useState<string>('');
  const [total, setTotal] = useState<number | null>(null);

  const calculate = () => {
    const c = parseFloat(initial) || 0;
    const p = parseFloat(monthly) || 0;
    const i = parseFloat(rate) / 100 / 12;
    const n = parseFloat(years) * 12;

    if (isNaN(i) || isNaN(n)) return;

    // FV = C * (1+i)^n + P * [((1+i)^n - 1) / i]
    const fv = c * Math.pow(1 + i, n) + p * ( (Math.pow(1 + i, n) - 1) / i );
    setTotal(fv);
  };

  return (
    <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 space-y-6">
      <h1 className="text-xl font-bold text-slate-800">Simulador de Investimento</h1>
      <div className="grid gap-4">
        <input type="number" placeholder="Investimento Inicial $" value={initial} onChange={e => setInitial(e.target.value)} className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-900 outline-none font-medium" />
        <input type="number" placeholder="Aporte Mensal $" value={monthly} onChange={e => setMonthly(e.target.value)} className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-900 outline-none font-medium" />
        <input type="number" placeholder="Taxa de Rendimento Anual %" value={rate} onChange={e => setRate(e.target.value)} className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-900 outline-none font-medium" />
        <input type="number" placeholder="Tempo em Anos" value={years} onChange={e => setYears(e.target.value)} className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-900 outline-none font-medium" />
      </div>
      <button onClick={calculate} className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl">Simular Patrimônio</button>
      
      {total && (
        <div className="p-6 bg-blue-50 rounded-2xl text-center">
          <p className="text-blue-500 font-bold uppercase text-xs mb-1">Patrimônio Estimado</p>
          <p className="text-3xl font-black text-blue-700">${total.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
        </div>
      )}
    </div>
  );
};

export default Investment;
