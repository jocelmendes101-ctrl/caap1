
import React, { useState } from 'react';
import { RefreshCcw, TrendingUp } from 'lucide-react';

type TargetVariable = 'S' | 'J' | 'C' | 'i' | 'n';

const CompoundInterest: React.FC = () => {
  const [target, setTarget] = useState<TargetVariable>('S');
  const [c, setC] = useState<string>('');
  const [i, setI] = useState<string>('');
  const [n, setN] = useState<string>('');
  const [s, setS] = useState<string>('');
  
  const [result, setResult] = useState<{
    value: number;
    label: string;
    symbol: string;
    complementary?: { label: string, value: number, symbol: string };
  } | null>(null);
  const [error, setError] = useState<string>('');

  const calculate = () => {
    setError('');
    const valC = parseFloat(c);
    const valI = parseFloat(i) / 100;
    const valN = parseFloat(n);
    const valS = parseFloat(s);

    try {
      if (target === 'S') {
        if (isNaN(valC) || isNaN(valI) || isNaN(valN)) throw new Error('Preencha C, i e n');
        const resS = valC * Math.pow(1 + valI, valN);
        setResult({ 
          value: resS, label: 'Capital Acumulado', symbol: 'S',
          complementary: { label: 'Juros Acumulados', value: resS - valC, symbol: 'J' }
        });
      } else if (target === 'J') {
        if (isNaN(valC) || isNaN(valI) || isNaN(valN)) throw new Error('Preencha C, i e n');
        const resS = valC * Math.pow(1 + valI, valN);
        const resJ = resS - valC;
        setResult({ 
          value: resJ, label: 'Juros Acumulados', symbol: 'J',
          complementary: { label: 'Capital Acumulado', value: resS, symbol: 'S' }
        });
      } else if (target === 'C') {
        if (isNaN(valS) || isNaN(valI) || isNaN(valN)) throw new Error('Preencha S, i e n');
        const resC = valS / Math.pow(1 + valI, valN);
        setResult({ 
          value: resC, label: 'Capital Inicial', symbol: 'C',
          complementary: { label: 'Juros Gerados', value: valS - resC, symbol: 'J' }
        });
      } else if (target === 'i') {
        if (isNaN(valS) || isNaN(valC) || isNaN(valN)) throw new Error('Preencha S, C e n');
        const resI = (Math.pow(valS / valC, 1 / valN) - 1) * 100;
        setResult({ value: resI, label: 'Taxa de Juros', symbol: 'i (%)' });
      } else if (target === 'n') {
        if (isNaN(valS) || isNaN(valC) || isNaN(valI)) throw new Error('Preencha S, C e i');
        const resN = Math.log(valS / valC) / Math.log(1 + valI);
        setResult({ value: resN, label: 'Período', symbol: 'n' });
      }
    } catch (e: any) {
      setError(e.message);
      setResult(null);
    }
  };

  const reset = () => {
    setC(''); setI(''); setN(''); setS(''); setResult(null); setError('');
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-100">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-xl font-black text-slate-900">Cálculo de Juro Composto</h1>
          <button onClick={reset} className="p-2 text-slate-400 hover:text-indigo-600 transition-colors">
            <RefreshCcw size={20} />
          </button>
        </div>

        <div className="mb-8">
          <label className="block text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-2">Qual variável deseja encontrar?</label>
          <select 
            value={target} 
            onChange={(e) => { setTarget(e.target.value as TargetVariable); setResult(null); }}
            className="w-full bg-indigo-50 border border-indigo-100 rounded-2xl px-5 py-4 text-indigo-900 font-bold outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="S">Capital Acumulado (S)</option>
            <option value="J">Juros (J)</option>
            <option value="C">Capital Inicial (C)</option>
            <option value="i">Taxa (i)</option>
            <option value="n">Período (n)</option>
          </select>
        </div>

        <div className="grid gap-6">
          {target !== 'C' && (
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Capital Inicial (C)</label>
              <input type="number" value={c} onChange={(e) => setC(e.target.value)} placeholder="0.00 CVE" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-3 text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none font-bold" />
            </div>
          )}

          {target !== 'S' && target !== 'J' && (
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Capital Acumulado (S)</label>
              <input type="number" value={s} onChange={(e) => setS(e.target.value)} placeholder="0.00 CVE" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-3 text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none font-bold" />
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {target !== 'i' && (
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Taxa % (i)</label>
                <input type="number" value={i} onChange={(e) => setI(e.target.value)} placeholder="Ex: 10" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-3 text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none font-bold" />
              </div>
            )}
            {target !== 'n' && (
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Período (n)</label>
                <input type="number" value={n} onChange={(e) => setN(e.target.value)} placeholder="Tempo" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-3 text-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none font-bold" />
              </div>
            )}
          </div>

          {error && <p className="text-red-500 text-xs font-bold">{error}</p>}

          <button onClick={calculate} className="w-full bg-indigo-600 text-white font-black py-4 rounded-2xl shadow-xl shadow-indigo-500/20 hover:bg-indigo-700 transition-all active:scale-95 uppercase tracking-widest">Resolver Equação</button>
        </div>
      </div>

      {result && (
        <div className="space-y-4 animate-in slide-in-from-top-6 duration-500">
          <div className="bg-gradient-to-br from-indigo-900 to-slate-900 p-8 rounded-[40px] text-center shadow-2xl relative overflow-hidden border border-indigo-800">
            <div className="absolute top-0 left-0 p-4 opacity-10"><TrendingUp size={100} className="text-white" /></div>
            <span className="text-[10px] text-indigo-300 font-black uppercase tracking-widest block mb-2">{result.label} ({result.symbol})</span>
            <p className="text-4xl font-black text-white">
              {target === 'i' ? `${result.value.toFixed(4)}%` : target === 'n' ? result.value.toFixed(2) : `${result.value.toLocaleString('pt-PT')} CVE`}
            </p>
          </div>

          {result.complementary && (
            <div className="bg-slate-100 p-6 rounded-[32px] text-center border border-slate-200">
              <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest block mb-1">{result.complementary.label} ({result.complementary.symbol})</span>
              <p className="text-2xl font-black text-slate-800">{result.complementary.value.toLocaleString('pt-PT')} CVE</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default CompoundInterest;
