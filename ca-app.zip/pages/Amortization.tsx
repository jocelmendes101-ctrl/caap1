
import React, { useState } from 'react';

const Amortization: React.FC = () => {
  const [val, setVal] = useState<string>('');
  const [tax, setTax] = useState<string>('');
  const [period, setPeriod] = useState<string>('');
  const [schedule, setSchedule] = useState<any[]>([]);

  const calculate = () => {
    const p = parseFloat(val);
    const i = parseFloat(tax) / 100 / 12; // monthly
    const n = parseInt(period);

    if (isNaN(p) || isNaN(i) || isNaN(n)) return;

    // PMT = P * [i(1+i)^n] / [(1+i)^n - 1]
    const pmt = p * (i * Math.pow(1 + i, n)) / (Math.pow(1 + i, n) - 1);
    
    let balance = p;
    const rows = [];
    for (let t = 1; t <= n; t++) {
      const interest = balance * i;
      const principal = pmt - interest;
      balance -= principal;
      rows.push({
        period: t,
        payment: pmt,
        interest,
        principal,
        balance: Math.max(0, balance)
      });
    }
    setSchedule(rows);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
        <h1 className="text-xl font-bold text-slate-800 mb-4">Simulador de Amortização (Price)</h1>
        <div className="grid sm:grid-cols-3 gap-4 mb-6">
          <input type="number" placeholder="Valor do Empréstimo $" value={val} onChange={e => setVal(e.target.value)} className="bg-slate-50 p-3 rounded-xl border border-slate-200 outline-none text-slate-900 font-medium" />
          <input type="number" placeholder="Taxa Anual %" value={tax} onChange={e => setTax(e.target.value)} className="bg-slate-50 p-3 rounded-xl border border-slate-200 outline-none text-slate-900 font-medium" />
          <input type="number" placeholder="Meses" value={period} onChange={e => setPeriod(e.target.value)} className="bg-slate-50 p-3 rounded-xl border border-slate-200 outline-none text-slate-900 font-medium" />
        </div>
        <button onClick={calculate} className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl">Simular</button>
      </div>

      {schedule.length > 0 && (
        <div className="bg-white rounded-3xl overflow-hidden shadow-sm border border-slate-100 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px]">
              <tr>
                <th className="px-4 py-3">Mês</th>
                <th className="px-4 py-3">Prestação</th>
                <th className="px-4 py-3">Juros</th>
                <th className="px-4 py-3">Amortização</th>
                <th className="px-4 py-3">Saldo Devedor</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {schedule.map(row => (
                <tr key={row.period} className="hover:bg-slate-50">
                  <td className="px-4 py-3 font-bold text-slate-900">{row.period}</td>
                  <td className="px-4 py-3 text-slate-800">${row.payment.toFixed(2)}</td>
                  <td className="px-4 py-3 text-red-500">${row.interest.toFixed(2)}</td>
                  <td className="px-4 py-3 text-green-600">${row.principal.toFixed(2)}</td>
                  <td className="px-4 py-3 text-slate-400">${row.balance.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default Amortization;
