
import React from 'react';
import { MapPin, Phone, Mail, Globe, Clock } from 'lucide-react';
import { SCHOOL_INFO } from '../constants';

const Contacts: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100">
        <h1 className="text-2xl font-bold text-slate-900 mb-2">Contactos Oficiais</h1>
        <p className="text-slate-500 text-sm mb-8">Estamos aqui para ajudar na sua jornada acadêmica.</p>

        <div className="space-y-6">
          <div className="flex items-start space-x-4">
            <div className="bg-blue-50 p-3 rounded-2xl text-blue-600">
              <MapPin size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Endereço</p>
              <p className="text-slate-700 font-medium">{SCHOOL_INFO.address}</p>
            </div>
          </div>

          <div className="flex items-start space-x-4">
            <div className="bg-green-50 p-3 rounded-2xl text-green-600">
              <Phone size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Telefone</p>
              <p className="text-slate-700 font-medium">{SCHOOL_INFO.phone}</p>
            </div>
          </div>

          <div className="flex items-start space-x-4">
            <div className="bg-purple-50 p-3 rounded-2xl text-purple-600">
              <Mail size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">E-mail</p>
              <p className="text-slate-700 font-medium">{SCHOOL_INFO.email}</p>
            </div>
          </div>

          <div className="flex items-start space-x-4">
            <div className="bg-orange-50 p-3 rounded-2xl text-orange-600">
              <Globe size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Website</p>
              <a href={`https://${SCHOOL_INFO.website}`} target="_blank" rel="noopener noreferrer" className="text-blue-600 font-bold hover:underline">
                {SCHOOL_INFO.website}
              </a>
            </div>
          </div>

          <div className="flex items-start space-x-4 border-t border-slate-100 pt-6">
            <div className="bg-slate-50 p-3 rounded-2xl text-slate-600">
              <Clock size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Horário de Atendimento</p>
              <p className="text-slate-700 font-medium">Segunda a Sexta: 08:00 - 17:00</p>
              <p className="text-slate-500 text-xs">Sábado: 08:00 - 12:00</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-slate-900 rounded-3xl h-48 flex items-center justify-center p-8 text-center text-white overflow-hidden relative">
        <div className="z-10">
          <h4 className="font-bold mb-2">Localização no Mapa</h4>
          <p className="text-xs text-slate-400">Podes encontrar-nos facilmente via GPS.</p>
        </div>
        {/* Placeholder image for a map */}
        <img src="https://picsum.photos/800/400?grayscale&blur=2" className="absolute inset-0 w-full h-full object-cover opacity-30" alt="Map background" />
      </div>
    </div>
  );
};

export default Contacts;
