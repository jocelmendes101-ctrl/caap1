
import React from 'react';
import { Page } from '../types';
import { NAV_ITEMS, APP_CONFIG } from '../constants';
import { Briefcase, BarChart4, PieChart } from 'lucide-react';

interface HomeProps {
  onNavigate: (page: Page) => void;
}

const Home: React.FC<HomeProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-8 pb-12">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-slate-900 to-blue-900 rounded-3xl p-8 text-white shadow-2xl overflow-hidden relative border border-slate-800">
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
          <div className="flex-1">
            <div className="bg-blue-600 inline-block px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mb-4">
              Contabilidade & Administração
            </div>
            <h1 className="text-4xl sm:text-5xl font-black mb-4 tracking-tighter">
              CA app
            </h1>
            <p className="text-blue-100 max-w-md text-sm sm:text-base mb-8 leading-relaxed font-medium">
              A ferramenta essencial para quem domina os números e a gestão. 
              Recursos de cálculo, teoria vasta e suporte de IA.
            </p>
            <div className="flex flex-wrap gap-4">
              <button 
                onClick={() => onNavigate('chat')}
                className="bg-white text-slate-900 px-8 py-3 rounded-2xl font-bold text-sm shadow-xl hover:bg-blue-50 transition-all active:scale-95"
              >
                Conversar com JC
              </button>
              <button 
                onClick={() => onNavigate('theory')}
                className="bg-slate-800/50 backdrop-blur-md text-white border border-slate-700 px-8 py-3 rounded-2xl font-bold text-sm hover:bg-slate-700/50 transition-all active:scale-95"
              >
                Ver Teoria
              </button>
            </div>
          </div>
          <div className="hidden md:flex items-center justify-center w-48 h-48 bg-blue-600/20 rounded-[40px] border border-blue-400/30 backdrop-blur-sm shadow-inner rotate-3">
             <PieChart size={80} className="text-blue-400" />
          </div>
        </div>
        
        {/* Abstract design elements */}
        <div className="absolute -top-12 -right-12 w-64 h-64 bg-blue-500/20 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-slate-500/10 rounded-full blur-2xl"></div>
      </div>

      {/* Info Cards about CA */}
      <div className="grid sm:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-4">
            <Briefcase size={24} />
          </div>
          <h3 className="font-bold text-slate-800 mb-2">Contabilidade</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            O coração financeiro de qualquer negócio. Registre, analise e projete o futuro econômico.
          </p>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mb-4">
            <BarChart4 size={24} />
          </div>
          <h3 className="font-bold text-slate-800 mb-2">Administração</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            A arte de gerir pessoas e processos para alcançar objetivos estratégicos de forma eficiente.
          </p>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <div className="w-12 h-12 bg-slate-50 text-slate-600 rounded-2xl flex items-center justify-center mb-4">
            <PieChart size={24} />
          </div>
          <h3 className="font-bold text-slate-800 mb-2">Fiscalidade</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Conformidade e estratégia tributária. Domine impostos como IVA e IR para segurança jurídica.
          </p>
        </div>
      </div>

      {/* Shortcuts Grid */}
      <div>
        <h3 className="text-slate-500 font-bold uppercase tracking-widest text-[10px] mb-4 px-1">Menu Rápido</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {NAV_ITEMS.filter(item => !['home', 'news', 'about'].includes(item.id)).slice(0, 4).map(item => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="flex flex-col items-center justify-center p-6 bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-md hover:border-blue-100 transition-all group"
            >
              <div className="mb-3 p-3 bg-slate-50 text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-600 rounded-xl transition-colors">
                {/* Cast icon to any to permit overriding size prop in cloneElement */}
                {React.cloneElement(item.icon as React.ReactElement<any>, { size: 24 })}
              </div>
              <span className="text-[11px] font-bold text-slate-700 text-center uppercase tracking-tighter">{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Website link section */}
      <div className="bg-slate-100 p-8 rounded-3xl border border-slate-200 text-center">
        <p className="text-slate-500 text-sm font-medium mb-2">Para mais recursos e informações acadêmicas, acesse o portal:</p>
        <a 
          href={`https://${APP_CONFIG.website}`} 
          target="_blank" 
          rel="noopener noreferrer" 
          className="text-xl font-black text-blue-600 hover:text-blue-700 transition-colors underline decoration-2 underline-offset-4"
        >
          {APP_CONFIG.website}
        </a>
      </div>
    </div>
  );
};

export default Home;
