
import React from 'react';
import { Calendar, User, ArrowRight } from 'lucide-react';

const News: React.FC = () => {
  const newsItems = [
    {
      id: '1',
      title: 'Seminário sobre Normas Internacionais de Contabilidade',
      date: '15 de Março, 2024',
      author: 'Prof. Manuel Silva',
      image: 'https://picsum.photos/600/400?random=10',
      category: 'Eventos'
    },
    {
      id: '2',
      title: 'Visita de Estudo ao Banco Nacional de Angola',
      date: '10 de Março, 2024',
      author: 'Coordenação',
      image: 'https://picsum.photos/600/400?random=11',
      category: 'Académico'
    },
    {
      id: '3',
      title: 'Novas calculadoras financeiras disponíveis no laboratório',
      date: '02 de Março, 2024',
      author: 'Administração',
      image: 'https://picsum.photos/600/400?random=12',
      category: 'Infraestrutura'
    }
  ];

  return (
    <div className="space-y-6 pb-12">
      <div className="flex items-center justify-between mb-2">
        <h1 className="text-2xl font-bold text-slate-900">Notícias & Galeria</h1>
        <span className="text-[10px] font-black bg-blue-100 text-blue-700 px-2 py-1 rounded">LIVE</span>
      </div>

      <div className="grid gap-6">
        {newsItems.map(item => (
          <div key={item.id} className="bg-white rounded-3xl overflow-hidden shadow-sm border border-slate-100 hover:shadow-md transition-shadow group cursor-pointer">
            <div className="h-48 overflow-hidden relative">
              <img src={item.image} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute top-4 left-4">
                <span className="bg-white/90 backdrop-blur px-3 py-1 rounded-full text-[10px] font-bold text-slate-800 shadow-sm">
                  {item.category}
                </span>
              </div>
            </div>
            <div className="p-6">
              <div className="flex items-center space-x-4 text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-2">
                <div className="flex items-center">
                  <Calendar size={12} className="mr-1" />
                  {item.date}
                </div>
                <div className="flex items-center">
                  <User size={12} className="mr-1" />
                  {item.author}
                </div>
              </div>
              <h2 className="text-lg font-bold text-slate-800 mb-3 group-hover:text-blue-600 transition-colors">{item.title}</h2>
              <div className="flex items-center text-blue-600 text-xs font-bold">
                Ler mais <ArrowRight size={14} className="ml-1" />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-blue-600 rounded-3xl p-8 text-white text-center">
        <h3 className="font-bold text-lg mb-2">Deseja contribuir?</h3>
        <p className="text-blue-100 text-sm mb-6">Envie fotos e notícias das vossas turmas para a secretaria para serem publicadas aqui.</p>
        <button className="bg-white text-blue-600 px-6 py-3 rounded-xl font-bold text-sm shadow-xl">Contactar Secretaria</button>
      </div>
    </div>
  );
};

export default News;
