
import React, { useState, useEffect } from 'react';
import { Plus, Trash2, CheckCircle2, Circle, StickyNote, Calendar } from 'lucide-react';
import { Note, ChecklistItem, AgendaItem } from '../types';

const StudyOrg: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'checklist' | 'notes' | 'agenda'>('checklist');
  
  // Storage logic
  const [checklist, setChecklist] = useState<ChecklistItem[]>(() => JSON.parse(localStorage.getItem('etgdh_checklist') || '[]'));
  const [notes, setNotes] = useState<Note[]>(() => JSON.parse(localStorage.getItem('etgdh_notes') || '[]'));
  
  useEffect(() => localStorage.setItem('etgdh_checklist', JSON.stringify(checklist)), [checklist]);
  useEffect(() => localStorage.setItem('etgdh_notes', JSON.stringify(notes)), [notes]);

  const addChecklistItem = (text: string) => {
    if (!text) return;
    setChecklist([...checklist, { id: Date.now().toString(), text, completed: false }]);
  };

  const addNote = (text: string) => {
    if (!text) return;
    setNotes([...notes, { id: Date.now().toString(), text, date: new Date().toLocaleDateString() }]);
  };

  return (
    <div className="space-y-6">
      <div className="flex bg-white p-1 rounded-2xl shadow-sm border border-slate-100">
        <button onClick={() => setActiveTab('checklist')} className={`flex-1 py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 ${activeTab === 'checklist' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400'}`}>
          <CheckCircle2 size={16} /> Checklist
        </button>
        <button onClick={() => setActiveTab('notes')} className={`flex-1 py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 ${activeTab === 'notes' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400'}`}>
          <StickyNote size={16} /> Notas
        </button>
      </div>

      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 min-h-[400px]">
        {activeTab === 'checklist' && (
          <div className="space-y-4">
            <div className="flex gap-2">
              <input id="checkInput" type="text" placeholder="Adicionar tópico..." className="flex-1 bg-slate-50 p-3 rounded-xl border border-slate-200 outline-none text-slate-900 font-medium" onKeyDown={e => e.key === 'Enter' && (addChecklistItem(e.currentTarget.value), e.currentTarget.value = '')} />
            </div>
            <div className="space-y-2">
              {checklist.map(item => (
                <div key={item.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl group">
                  <button onClick={() => setChecklist(checklist.map(i => i.id === item.id ? {...i, completed: !i.completed} : i))} className="flex items-center gap-3">
                    {item.completed ? <CheckCircle2 className="text-green-500" /> : <Circle className="text-slate-300" />}
                    <span className={`text-sm font-medium ${item.completed ? 'line-through text-slate-400' : 'text-slate-700'}`}>{item.text}</span>
                  </button>
                  <button onClick={() => setChecklist(checklist.filter(i => i.id !== item.id))} className="opacity-0 group-hover:opacity-100 text-red-400 p-1">
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'notes' && (
          <div className="space-y-4">
            <textarea id="noteInput" placeholder="Escreva uma nota ou lembrete..." className="w-full bg-slate-50 p-4 rounded-2xl border border-slate-200 outline-none min-h-[100px] text-slate-900 font-medium" onKeyDown={e => e.key === 'Enter' && !e.shiftKey && (addNote(e.currentTarget.value), e.currentTarget.value = '')}></textarea>
            <div className="grid sm:grid-cols-2 gap-4">
              {notes.map(note => (
                <div key={note.id} className="p-4 bg-yellow-50 border border-yellow-100 rounded-2xl shadow-sm relative">
                  <p className="text-xs text-yellow-600 font-bold mb-2">{note.date}</p>
                  <p className="text-sm text-slate-700 whitespace-pre-wrap">{note.text}</p>
                  <button onClick={() => setNotes(notes.filter(n => n.id !== note.id))} className="absolute top-4 right-4 text-yellow-600">
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default StudyOrg;
