
import React, { useState } from 'react';
import { Lightbulb, Send, Loader2, Save, FileText, CheckCircle, AlertTriangle, TrendingUp, Sparkles } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

const BusinessViability: React.FC = () => {
  const [description, setDescription] = useState('');
  const [resources, setResources] = useState('');
  const [goals, setGoals] = useState('');
  const [market, setMarket] = useState('');
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);

  const handleAnalyze = async () => {
    if (!description || !resources || !goals) return;

    setLoading(true);
    setAnalysis(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Analise a viabilidade do seguinte negócio para o CA app:
      - Descrição: ${description}
      - Recursos: ${resources}
      - Objetivos: ${goals}
      - Mercado/Concorrência: ${market || 'Não informado'}

      Siga rigorosamente esta estrutura de resposta (use Markdown):
      1. Classificação de Viabilidade (Alta, Média ou Baixa) com uma breve justificativa.
      2. Análise FOFA (Forças, Oportunidades, Fraquezas e Ameaças) em formato de lista.
      3. 5 Sugestões Práticas de Melhoria.
      4. Estratégias de Marketing e Vendas recomendadas.
      5. Lista de 5 Sugestões de Nomes e Slogans Criativos.

      Mantenha um tom profissional de consultor de contabilidade e administração.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          systemInstruction: 'Você é JC, o consultor sênior do CA app. Sua especialidade é viabilidade financeira, estratégica e operacional de novos negócios.',
        }
      });

      setAnalysis(response.text || "Não foi possível gerar a análise.");
    } catch (err) {
      setAnalysis("Erro ao processar análise. Verifique sua conexão.");
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setDescription('');
    setResources('');
    setGoals('');
    setMarket('');
    setAnalysis(null);
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-blue-600 p-2 rounded-xl text-white">
            <Lightbulb size={24} />
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Viabilidade de Negócio</h1>
        </div>

        {!analysis ? (
          <div className="space-y-6">
            <p className="text-sm text-slate-500 font-medium">Descreva sua ideia para receber uma análise FOFA (SWOT) completa, dicas de marketing e sugestões de nomes.</p>
            
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Descrição do Negócio</label>
                <textarea 
                  value={description} 
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Ex: Abrir uma cafeteria gourmet no centro da cidade focada em café orgânico."
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-sm text-slate-900 focus:ring-2 focus:ring-blue-500 outline-none font-medium min-h-[100px]"
                />
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Recursos Disponíveis</label>
                  <input 
                    type="text" 
                    value={resources} 
                    onChange={e => setResources(e.target.value)}
                    placeholder="Capital, equipe, equipamentos..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-sm text-slate-900 focus:ring-2 focus:ring-blue-500 outline-none font-medium"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Objetivos (Prazos)</label>
                  <input 
                    type="text" 
                    value={goals} 
                    onChange={e => setGoals(e.target.value)}
                    placeholder="Lucro em 6 meses, expansão..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-sm text-slate-900 focus:ring-2 focus:ring-blue-500 outline-none font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Mercado / Concorrência (Opcional)</label>
                <input 
                  type="text" 
                  value={market} 
                  onChange={e => setMarket(e.target.value)}
                  placeholder="Ex: Muitos concorrentes diretos, bairro residencial..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-sm text-slate-900 focus:ring-2 focus:ring-blue-500 outline-none font-medium"
                />
              </div>
            </div>

            <button 
              onClick={handleAnalyze}
              disabled={loading || !description || !resources || !goals}
              className="w-full bg-blue-600 text-white font-black py-4 rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 disabled:opacity-50 active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 size={20} className="animate-spin" /> : <Sparkles size={20} />}
              {loading ? "GERANDO RELATÓRIO..." : "ANALISAR VIABILIDADE"}
            </button>
          </div>
        ) : (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center justify-between">
              <span className="bg-blue-100 text-blue-700 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest">Relatório Gerado por JC</span>
              <button onClick={resetForm} className="text-slate-400 hover:text-blue-600 text-xs font-bold transition-colors">Nova Análise</button>
            </div>

            <div className="prose prose-slate max-w-none text-slate-800 text-sm leading-relaxed space-y-4">
              {analysis.split('\n').map((line, i) => (
                <p key={i} className={line.startsWith('#') ? 'font-black text-slate-900 border-b pb-2 mt-6 mb-2 text-base' : ''}>
                  {line.replace(/^#+\s/, '')}
                </p>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-4 pt-8">
              <button className="flex items-center justify-center gap-2 bg-slate-900 text-white font-bold py-4 rounded-2xl text-xs hover:bg-slate-800 transition-all">
                <Save size={16} /> SALVAR RELATÓRIO
              </button>
              <button className="flex items-center justify-center gap-2 bg-white border border-slate-200 text-slate-800 font-bold py-4 rounded-2xl text-xs hover:bg-slate-50 transition-all">
                <FileText size={16} /> EXPORTAR PDF
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="bg-blue-600 p-8 rounded-[40px] text-white flex flex-col items-center text-center gap-4 relative overflow-hidden shadow-2xl">
        <TrendingUp size={80} className="absolute -bottom-4 -right-4 opacity-10" />
        <h3 className="text-lg font-black tracking-tight relative z-10">Precisa de Projeção Financeira?</h3>
        <p className="text-blue-100 text-xs max-w-xs relative z-10 font-medium opacity-80">
          Após a análise estratégica, use nossos simuladores de investimento e juros para planejar o capital inicial.
        </p>
      </div>
    </div>
  );
};

export default BusinessViability;
