
import React, { useState } from 'react';
import { Calculator, RefreshCw, Landmark, ShieldCheck } from 'lucide-react';

const SalaryCalculator: React.FC = () => {
  const [base, setBase] = useState<string>('');
  const [food, setFood] = useState<string>('');
  const [transport, setTransport] = useState<string>('');
  const [vacation, setVacation] = useState<string>('');
  const [overtime, setOvertime] = useState<string>('');
  const [bonus, setBonus] = useState<string>('');
  const [workerType, setWorkerType] = useState<'estado' | 'privado'>('privado');
  const [hasUnion, setHasUnion] = useState(false);

  const [result, setResult] = useState<{
    bruto: number;
    inps: number;
    irps: number;
    sindicato: number;
    deductions: number;
    liquido: number;
  } | null>(null);

  const calculate = () => {
    const vBase = parseFloat(base) || 0;
    const vFood = parseFloat(food) || 0;
    const vTransport = parseFloat(transport) || 0;
    const vVacation = parseFloat(vacation) || 0;
    const vOvertime = parseFloat(overtime) || 0;
    const vBonus = parseFloat(bonus) || 0;

    const bruto = vBase + vFood + vTransport + vVacation + vOvertime + vBonus;
    
    // INPS logic
    const inpsRate = workerType === 'estado' ? 0.08 : 0.085;
    const inps = bruto * inpsRate;

    // IRPS logic based on provided formulas
    let irps = 0;
    if (bruto <= 80000) {
      irps = bruto * 0.14 - 5125;
    } else if (bruto <= 150000) {
      irps = bruto * 0.21 - 10725;
    } else {
      irps = bruto * 0.25 - 16725;
    }
    if (irps < 0) irps = 0;

    // Sindicato logic
    const sindicato = hasUnion ? bruto * 0.01 : 0;

    const deductions = inps + irps + sindicato;
    const liquido = bruto - deductions;

    setResult({ bruto, inps, irps, sindicato, deductions, liquido });
  };

  const reset = () => {
    setBase(''); setFood(''); setTransport(''); setVacation(''); setOvertime(''); setBonus('');
    setResult(null);
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-100">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Cálculo de Salário Líquido</h1>
          <button onClick={reset} className="p-2 text-slate-400 hover:text-blue-600 transition-colors">
            <RefreshCw size={20} />
          </button>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Salário Base (CVE)</label>
              <input 
                type="number" value={base} onChange={e => setBase(e.target.value)} 
                placeholder="Ex: 50000"
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-slate-900 focus:ring-2 focus:ring-blue-500 outline-none font-bold"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Alimentação</label>
                <input type="number" value={food} onChange={e => setFood(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 outline-none" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Transporte</label>
                <input type="number" value={transport} onChange={e => setTransport(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 outline-none" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Férias/Natal</label>
                <input type="number" value={vacation} onChange={e => setVacation(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 outline-none" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Horas Extras</label>
                <input type="number" value={overtime} onChange={e => setOvertime(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 outline-none" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Bónus/Comissões</label>
              <input type="number" value={bonus} onChange={e => setBonus(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 outline-none" />
            </div>
          </div>

          <div className="space-y-6 bg-slate-50 p-6 rounded-3xl border border-slate-200">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <Landmark size={18} className="text-blue-600" /> Configurações Legais
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Tipo de Trabalhador</label>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setWorkerType('privado')}
                    className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all border ${workerType === 'privado' ? 'bg-blue-600 text-white border-blue-700 shadow-md' : 'bg-white text-slate-500 border-slate-200'}`}
                  >
                    Privado (8.5%)
                  </button>
                  <button 
                    onClick={() => setWorkerType('estado')}
                    className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all border ${workerType === 'estado' ? 'bg-blue-600 text-white border-blue-700 shadow-md' : 'bg-white text-slate-500 border-slate-200'}`}
                  >
                    Estado (8%)
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 bg-white rounded-2xl border border-slate-200">
                <input 
                  type="checkbox" 
                  id="union" 
                  checked={hasUnion} 
                  onChange={e => setHasUnion(e.target.checked)}
                  className="w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="union" className="text-sm font-bold text-slate-700 cursor-pointer flex-1">
                  Descontar Sindicato (1%)
                </label>
              </div>
            </div>

            <button 
              onClick={calculate}
              className="w-full bg-blue-600 text-white font-black py-4 rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 active:scale-95 transition-all mt-4"
            >
              CALCULAR SALÁRIO
            </button>
          </div>
        </div>
      </div>

      {result && (
        <div className="grid md:grid-cols-3 gap-6 animate-in slide-in-from-bottom-4 duration-500">
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
            <p className="text-[10px] text-slate-400 font-black uppercase mb-2">Salário Bruto</p>
            <p className="text-3xl font-black text-slate-900">{result.bruto.toLocaleString('pt-PT')} CVE</p>
          </div>
          
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm relative overflow-hidden">
             <div className="absolute top-0 right-0 p-3 text-red-100"><ShieldCheck size={40} /></div>
             <p className="text-[10px] text-red-400 font-black uppercase mb-4">Deduções Totais</p>
             <div className="space-y-2">
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-slate-400">INPS ({workerType === 'estado' ? '8%' : '8.5%'})</span>
                  <span className="text-slate-700">{result.inps.toLocaleString('pt-PT')} CVE</span>
                </div>
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-slate-400">IRPS (Escalão)</span>
                  <span className="text-slate-700">{result.irps.toLocaleString('pt-PT')} CVE</span>
                </div>
                {hasUnion && (
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-400">Sindicato (1%)</span>
                    <span className="text-slate-700">{result.sindicato.toLocaleString('pt-PT')} CVE</span>
                  </div>
                )}
                <div className="pt-2 border-t border-slate-100 flex justify-between text-sm font-black text-red-600">
                  <span>TOTAL</span>
                  <span>{result.deductions.toLocaleString('pt-PT')} CVE</span>
                </div>
             </div>
          </div>

          <div className="bg-blue-600 p-8 rounded-3xl shadow-2xl flex flex-col justify-center text-center">
            <p className="text-[10px] text-blue-200 font-black uppercase mb-2 tracking-widest">Salário Líquido Final</p>
            <p className="text-4xl font-black text-white">{result.liquido.toLocaleString('pt-PT')} CVE</p>
            <p className="text-[10px] text-blue-300 mt-4 italic opacity-70">Valores calculados com base nas tabelas CVE vigentes.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default SalaryCalculator;
