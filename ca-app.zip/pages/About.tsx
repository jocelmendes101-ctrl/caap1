
import React from 'react';
import { Target, TrendingUp, Users, ShieldCheck } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 space-y-12">
      <div className="text-center max-w-2xl mx-auto space-y-4">
        <h1 className="text-3xl font-black text-slate-900 tracking-tight">O Mundo da Contabilidade & Administração</h1>
        <p className="text-slate-500 leading-relaxed font-medium">
          Profissões dinâmicas que fundamentam a economia global. Conheça as competências e as áreas de atuação para quem busca o sucesso corporativo.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 gap-8">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-lg text-white">
              <ShieldCheck size={20} />
            </div>
            <h3 className="text-lg font-bold text-slate-800">Responsabilidade Ética</h3>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">
            Contabilistas e administradores são os guardiões da transparência. A ética profissional é o alicerce para a confiança dos investidores e do mercado.
          </p>
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-lg text-white">
              <TrendingUp size={20} />
            </div>
            <h3 className="text-lg font-bold text-slate-800">Crescimento Estratégico</h3>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">
            Além de registrar números, o profissional moderno analisa dados para prever tendências e apoiar a tomada de decisão no topo das organizações.
          </p>
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-600 p-2 rounded-lg text-white">
              <Target size={20} />
            </div>
            <h3 className="text-lg font-bold text-slate-800">Multifuncionalidade</h3>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">
            A atuação abrange áreas como RH, Marketing, Finanças, Logística e Compliance, tornando o profissional indispensável em qualquer setor.
          </p>
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="bg-slate-800 p-2 rounded-lg text-white">
              <Users size={20} />
            </div>
            <h3 className="text-lg font-bold text-slate-800">Liderança de Pessoas</h3>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">
            Administrar é gerir talentos. Desenvolver soft skills como comunicação e inteligência emocional é crucial para gerir equipes de alta performance.
          </p>
        </div>
      </div>

      <div className="bg-slate-50 p-8 rounded-3xl border border-slate-100">
        <h3 className="font-black text-slate-900 mb-4 uppercase tracking-widest text-xs">Principais Atuações</h3>
        <ul className="grid sm:grid-cols-2 gap-3">
          {['Auditoria Interna e Externa', 'Perícia Contábil', 'Controladoria', 'Gestão Financeira', 'Consultoria de Negócios', 'Planejamento Tributário'].map(item => (
            <li key={item} className="flex items-center gap-2 text-sm text-slate-700 font-medium">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
              {item}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default About;
