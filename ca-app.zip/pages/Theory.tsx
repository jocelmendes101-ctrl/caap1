
import React from 'react';
import { BookOpen, PieChart, ShoppingCart, Percent, Globe } from 'lucide-react';

const Theory: React.FC = () => {
  return (
    <div className="space-y-12 pb-24">
      {/* Introduction */}
      <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100">
        <h1 className="text-3xl font-black text-slate-900 mb-4">Base Teórica CA</h1>
        <p className="text-slate-500 text-sm sm:text-base leading-relaxed">
          Explore os pilares fundamentais da Contabilidade e Administração. Do cálculo de juros à macroeconomia.
        </p>
      </div>

      <div className="grid gap-8">
        {/* Section: Impostos e IVA */}
        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-xl text-white">
              <Percent size={20} />
            </div>
            <h2 className="text-xl font-black text-slate-800">Fiscalidade e IVA</h2>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-3">
              <h4 className="font-bold text-blue-600">IVA (Imposto sobre o Valor Acrescentado)</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Imposto indireto que incide sobre o consumo de bens e serviços. Em Angola, a taxa padrão é de 14%, com taxas reduzidas para produtos essenciais.
              </p>
              <div className="bg-blue-50 p-3 rounded-xl border border-blue-100 font-mono text-[10px]">
                Preço Final = Preço Base * (1 + Taxa_IVA)
              </div>
            </div>
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-3">
              <h4 className="font-bold text-slate-800">Impostos Diretos vs Indiretos</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                <span className="font-bold text-slate-700">Diretos:</span> Incidem sobre o rendimento (ex: IRT, II).<br/>
                <span className="font-bold text-slate-700">Indiretos:</span> Incidem sobre o consumo (ex: IVA, IEC).
              </p>
            </div>
          </div>
        </section>

        {/* Section: Comércio */}
        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-600 p-2 rounded-xl text-white">
              <ShoppingCart size={20} />
            </div>
            <h2 className="text-xl font-black text-slate-800">Gestão Comercial</h2>
          </div>
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
            <div className="grid sm:grid-cols-3 gap-6">
              <div className="space-y-2">
                <h4 className="font-bold text-sm text-slate-800">Margem de Lucro</h4>
                <p className="text-xs text-slate-500 leading-relaxed">A diferença entre o preço de venda e o custo de produção, expressa em percentagem.</p>
              </div>
              <div className="space-y-2">
                <h4 className="font-bold text-sm text-slate-800">Markup</h4>
                <p className="text-xs text-slate-500 leading-relaxed">Índice aplicado sobre o custo para definir o preço de venda final.</p>
              </div>
              <div className="space-y-2">
                <h4 className="font-bold text-sm text-slate-800">Giro de Estoque</h4>
                <p className="text-xs text-slate-500 leading-relaxed">Frequência com que o estoque é renovado num determinado período.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Section: Economia */}
        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-xl text-white">
              <Globe size={20} />
            </div>
            <h2 className="text-xl font-black text-slate-800">Economia</h2>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="bg-slate-900 text-white p-8 rounded-3xl space-y-4">
              <h4 className="font-bold text-indigo-400">Microeconomia</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Estuda o comportamento de agentes individuais: consumidores e empresas. Foco em Oferta e Procura.
              </p>
            </div>
            <div className="bg-slate-900 text-white p-8 rounded-3xl space-y-4">
              <h4 className="font-bold text-blue-400">Macroeconomia</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Estuda o funcionamento da economia como um todo: PIB, Inflação, Desemprego e Balança Comercial.
              </p>
            </div>
          </div>
        </section>

        {/* Section: Juros (Previous content maintained but styled) */}
        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="bg-slate-800 p-2 rounded-xl text-white">
              <PieChart size={20} />
            </div>
            <h2 className="text-xl font-black text-slate-800">Matemática Financeira</h2>
          </div>
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
             <div className="grid sm:grid-cols-2 gap-8">
                <div className="space-y-3">
                  <h4 className="font-bold text-slate-800">Capitalização Simples</h4>
                  <p className="text-xs text-slate-500">Juros sobre o capital original.</p>
                  <code className="block bg-slate-50 p-3 rounded-xl text-blue-600 font-bold text-center border border-slate-100">j = C * i * n</code>
                </div>
                <div className="space-y-3">
                  <h4 className="font-bold text-slate-800">Capitalização Composta</h4>
                  <p className="text-xs text-slate-500">Juros sobre juros.</p>
                  <code className="block bg-slate-50 p-3 rounded-xl text-indigo-600 font-bold text-center border border-slate-100">M = C * (1 + i)^n</code>
                </div>
             </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Theory;
