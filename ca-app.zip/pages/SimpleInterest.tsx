
import React, { useState } from 'react';
import { RefreshCcw, HelpCircle } from 'lucide-react';
import { PeriodUnit } from '../types';

type TargetVariable = 'j' | 'C' | 'i' | 'n';

const SimpleInterest: React.FC = () => {
  const [target, setTarget] = useState<TargetVariable>('j');
  const [c, setC] = useState<string>('');
  const [i, setI] = useState<string>('');
  const [n, setN] = useState<string>('');
  const [j, setJ] = useState<string>('');
  const [unit, setUnit] = useState<PeriodUnit>('months');
  
  const [result, setResult] = useState<{
    value: number;
    label: string;
    symbol: string;
    secondary?: { label: string, value: number, symbol: string };
  } | null>(null);
  const [error, setError] = useState<string>('');

  const calculate = () => {
    setError('');
    const valC = parseFloat(c);
    const valI = parseFloat(i) / 100;
    const valN = parseFloat(n);
    const valJ = parseFloat(j);

    try {
      if (target === 'j') {
        if (isNaN(valC) || isNaN(valI) || isNaN(valN)) throw new Error('Preencha C, i e n');
        const resJ = valC * valI * valN;
        setResult({ 
          value: resJ, label: 'Juros', symbol: 'j',
          secondary: { label: 'Capital Acumulado', value: valC + resJ, symbol: 'S' }
        });
      } else if (target === 'C') {
        if (isNaN(valJ) || isNaN(valI) || isNaN(valN)) throw new Error('Preencha j, i e n');
        const resC = valJ / (valI * valN);
        setResult({ 
          value: resC, label: 'Capital Inicial', symbol: 'C',
          secondary: { label: 'Capital Acumulado', value: resC + valJ, symbol: 'S' }
        });
      } else if (target === 'i') {
        if (isNaN(valJ) || isNaN(valC) || isNaN(valN)) throw new Error('Preencha j, C e n');
        const resI = (valJ / (valC * valN)) * 100;
        setResult({ value: resI, label: 'Taxa de Juros', symbol: 'i (%)' });
      } else if (target === 'n') {
        if (isNaN(valJ) || isNaN(valC) || isNaN(valI)) throw new Error('Preencha j, C e i');
        const resN = valJ / (valC * valI);
        setResult({ value: resN, label: 'Período', symbol: 'n' });
      }
    } catch (e: any) {
      setError(e.message);
      setResult(null);
    }
  };

  const reset = () => {
    setC(''); setI(''); setN(''); setJ(''); setResult(null); setError('');
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-100">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-xl font-black text-slate-900 tracking-tight">Cálculo de Juro Simples</h1>
          <button onClick={reset} className="p-2 text-slate-400 hover:text-blue-600 transition-colors">
            <RefreshCcw size={20} />
          </button>
        </div>

        <div className="mb-8">
          <label className="block text-[10px] font-black text-blue-600 uppercase tracking-widest mb-2">O que deseja calcular?</label>
          <select 
            value={target} 
            onChange={(e) => { setTarget(e.target.value as TargetVariable); setResult(null); }}
            className="w-full bg-blue-50 border border-blue-100 rounded-2xl px-5 py-4 text-blue-900 font-bold outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="j">Juros (j)</option>
            <option value="C">Capital Inicial (C)</option>
            <option value="i">Taxa (i)</option>
            <option value="n">Período (n)</option>
          </select>
        </div>

        <div className="grid gap-6">
          {target !== 'C' && (
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Capital Inicial (C)</label>
              <input type="number" value={c} onChange={(e) => setC(e.target.value)} placeholder="Valor inicial em CVE" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-3 text-slate-900 focus:ring-2 focus:ring-blue-500 outline-none font-bold placeholder:text-slate-300" />
            </div>
          )}

          {target !== 'j' && (
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Juros (j)</label>
              <input type="number" value={j} onChange={(e) => setJ(e.target.value)} placeholder="Total de juros em CVE" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-3 text-slate-900 focus:ring-2 focus:ring-blue-500 outline-none font-bold placeholder:text-slate-300" />
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {target !== 'i' && (
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Taxa (i) %</label>
                <input type="number" value={i} onChange={(e) => setI(e.target.value)} placeholder="Ex: 5" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-3 text-slate-900 focus:ring-2 focus:ring-blue-500 outline-none font-bold placeholder:text-slate-300" />
              </div>
            )}
            {target !== 'n' && (
              <div className="flex gap-2 items-end">
                <div className="flex-1">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Período (n)</label>
                  <input type="number" value={n} onChange={(e) => setN(e.target.value)} placeholder="Tempo" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-3 text-slate-900 focus:ring-2 focus:ring-blue-500 outline-none font-bold placeholder:text-slate-300" />
                </div>
                <select value={unit} onChange={(e) => setUnit(e.target.value as PeriodUnit)} className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-3 text-slate-900 outline-none font-bold h-[50px]">
                  <option value="days">Dias</option>
                  <option value="months">Meses</option>
                  <option value="years">Anos</option>
                </select>
              </div>
            )}
          </div>

          {error && <p className="text-red-500 text-xs font-bold animate-pulse">{error}</p>}

          <button onClick={calculate} className="w-full bg-blue-600 text-white font-black py-4 rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all active:scale-95">CALCULAR {target.toUpperCase()}</button>
        </div>
      </div>

      {result && (
        <div className="space-y-4 animate-in zoom-in duration-300">
          <div className="bg-slate-900 p-8 rounded-[40px] border border-slate-800 shadow-2xl text-center relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10"><HelpCircle size={80} className="text-white" /></div>
            <span className="text-[10px] text-blue-400 font-black uppercase tracking-widest block mb-2">{result.label} ({result.symbol})</span>
            <p className="text-4xl font-black text-white">
              {target === 'i' ? `${result.value.toFixed(2)}%` : target === 'n' ? `${result.value.toFixed(2)} ${unit}` : `${result.value.toLocaleString('pt-PT')} CVE`}
            </p>
          </div>

          {result.secondary && (
            <div className="bg-blue-600 p-6 rounded-[32px] text-center shadow-lg border border-blue-500">
              <span className="text-[10px] text-blue-200 font-black uppercase tracking-widest block mb-1">{result.secondary.label} ({result.secondary.symbol})</span>
              <p className="text-2xl font-black text-white">{result.secondary.value.toLocaleString('pt-PT')} CVE</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SimpleInterest;
