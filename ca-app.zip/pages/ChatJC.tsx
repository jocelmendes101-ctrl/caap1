
import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, MessageSquare } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

const ChatJC: React.FC = () => {
  const [messages, setMessages] = useState<{role: 'user' | 'bot', text: string}[]>([
    { role: 'bot', text: 'Olá! Eu sou o JC, seu assistente inteligente do CA app. Especialista em Contabilidade, Gestão, Fiscalidade e Economia. Como posso te auxiliar hoje?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: userMsg,
        config: {
          systemInstruction: 'Você é JC, um assistente virtual de elite do "CA app". Sua especialidade é Contabilidade, Custos, Direito Comercial, Fiscalidade (foco em IVA angolano e impostos em CVE), Marketing, Comércio, Negócios, Política Econômica, Macroeconomia e Matemática Financeira. Use linguagem profissional mas acessível. Explique fórmulas matematicamente se solicitado. Use sempre o símbolo "$" para valores monetários globais ou "CVE" quando o contexto for específico de Cabo Verde. Não mencione nomes de escolas específicas, apenas refira-se ao CA app.',
        }
      });

      const botText = response.text || "Desculpe, tive um problema ao processar sua pergunta.";
      setMessages(prev => [...prev, { role: 'bot', text: botText }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'bot', text: "Erro ao conectar com JC. Verifique sua conexão à internet." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-160px)] bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
      <div className="bg-slate-900 p-4 flex items-center gap-3 border-b border-slate-800">
        <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
          <Bot size={20} />
        </div>
        <div>
          <h3 className="text-white font-bold text-sm">JC - Assistente IA</h3>
          <p className="text-[10px] text-blue-400 font-bold uppercase tracking-widest">Contabilidade & Gestão</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50/30">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] p-4 rounded-2xl text-sm leading-relaxed ${m.role === 'user' ? 'bg-blue-600 text-white rounded-tr-none shadow-md' : 'bg-white text-slate-800 rounded-tl-none border border-slate-100 shadow-sm'}`}>
              <div className={`font-bold text-[9px] uppercase mb-1 ${m.role === 'user' ? 'text-blue-200' : 'text-slate-400'}`}>
                {m.role === 'user' ? 'Usuário' : 'JC Assistant'}
              </div>
              {m.text}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white p-4 rounded-2xl rounded-tl-none flex items-center gap-3 border border-slate-100 shadow-sm">
              <div className="flex gap-1">
                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{animationDelay: '0ms'}}></div>
                <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{animationDelay: '150ms'}}></div>
                <div className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce" style={{animationDelay: '300ms'}}></div>
              </div>
              <span className="text-xs text-slate-400 font-bold uppercase tracking-widest">Analisando...</span>
            </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      <div className="p-4 border-t bg-white flex gap-2">
        <input 
          type="text" 
          value={input} 
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          placeholder="Pergunte sobre IVA, Juros, Balanço ou Economia..."
          className="flex-1 bg-slate-50 border border-slate-100 rounded-2xl px-5 py-3 text-sm text-slate-900 focus:ring-2 focus:ring-blue-500 outline-none transition-all font-medium"
        />
        <button 
          onClick={handleSend}
          disabled={loading}
          className="bg-blue-600 text-white p-3 rounded-2xl shadow-lg hover:bg-blue-700 disabled:opacity-50 active:scale-95 transition-all"
        >
          <Send size={20} />
        </button>
      </div>
    </div>
  );
};

export default ChatJC;
